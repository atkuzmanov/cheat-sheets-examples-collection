package scala2e.chapter10

import Spiral.spiral

object App extends App {
  /*
  val uniform = elem('u', 8, 1)
  val array = elem(Array("array1"))
  val line = elem("line")
  
  println(uniform above array above line)
  *
  */
  
  println(spiral(14, 0))

}