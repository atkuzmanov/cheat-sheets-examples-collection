package scala2e.chapter12

class Point(val x: Int, val y: Int)