package scala2e.chapter12.intqueue

abstract class IntQueue {
  def get: Int
  def put(x: Int)

}