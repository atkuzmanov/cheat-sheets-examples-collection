package scala2e.chapter12.intqueue

class MyQueue extends BasicIntQueue with Doubling {
 
}