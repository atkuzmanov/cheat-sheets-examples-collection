package scala2e.chapter29.recipesApp.tests

import scala2e.chapter29.recipesApp.application.Browser

object SimpleBrowser extends Browser {
  val database = SimpleDatabase
}