package scala2e.chapter29.recipesApp.tests

import scala2e.chapter29.recipesApp.application.Database

object OtherSimpleDatabase extends Database
  with SimpleFoods with SimpleRecipes